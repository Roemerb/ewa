/**
 * Created by Rene on 27-10-2016.
 */

import { routerReducer } from 'react-router-redux'


const reducers = {
    routing: routerReducer
}

export default reducers
