export default {
    'website.name': 'Student Dashboard'
}