/**
 * Created by Onkarjit Singh on 8-11-2016.
 */

import React from "react";

export default class NotificationsInbox extends React.Component {

    render() {
        return (

           <h1>test</h1>
        );
    }
}