// import React from "react";
// class ProgressBarFill extends React.Component {
//
//     render() {
//         const progressStyle = {
//             width: this.props.percentage
//         };
//         return (
//             <div className="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style={progressStyle}>
//                <span >{this.props.punten} punten gehaald</span>
//             </div>
//
//         );
//     }
//
// }
// ;
// class ProgressStats extends  React.Component {
//     render() {
//         const divStyle = {
//             width: this.props.percentage
//         };
//         return (
//             <div className="puntenOverzicht">
//                 <p>Studiepunten (eenh.): 600 vereist, 19 behaald, 41 nodig</p>
//                 <p>Studiedelen: 13 vereist, 6 behaald, 7 nodig</p>
//                 <button disabled>Propedeuse verzoek genereren</button>
//             </div>
//
//         );
//     }
// }
// React.render(<ProgressBarFill percentage="700" punten="100"/>, document.getElementById('progress'));
// // React.render(<puntenOverzicht/>, document.getElementById('progress-stats'));
//
